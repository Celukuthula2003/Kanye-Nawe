import os
from flask import Flask, render_template, request, g
import sqlite3

app = Flask(__name__)

# Define the path to the SQLite database
DATABASE = os.path.join(app.root_path, 'data', 'kanye.db')

# Function to get the SQLite database connection
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

# Teardown function to close the database connection at the end of each request
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# Route to display the home page
@app.route('/', methods=['GET'])
def show_home():
    return render_template('index.html')

# Route to process the contact form submission
@app.route('/quote', methods=['POST'])
def process_contact_form():
    # Get form data
    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']
    service = request.form['service']
    details = request.form['details']

    # Get database connection
    db = get_db()
    c = db.cursor()

    # Insert form data into the contacts table
    c.execute("INSERT INTO contacts (name, email, phone, service, details) VALUES (?, ?, ?, ?, ?)",
              (name, email, phone, service, details))

    # Commit changes
    db.commit()

    # Render the thank_you.html template
    return render_template('thank_you.html', service=service)
@app.route('/contact', methods=['POST'])
def handle_contact():
    # Get form data
    name = request.form['name']
    email = request.form['email']
    message = request.form['message']

    # Get database connection
    db = get_db()
    c = db.cursor()

    # Insert form data into the contacts table
    c.execute("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)",
              (name, email, message))

    # Commit changes
    db.commit()

    # Close the database connection
    db.close()

    # Redirect to a thank you page
    return render_template('thank_you.html')

# Route to display a thank you page
@app.route('/thank_you')
def thank_you():
    return render_template('thank_you.html')

@app.route("/selectMethod", methods=["POST"])
def select_payment_method():
    payment_method = request.form.get("paymentMethod")

    if payment_method == "creditCard":
        # Handle credit card payment logic (e.g., redirect to creditPayment.html)
        return render_template('creditCard.html')

    elif payment_method == "paypal":
        # Handle PayPal payment logic (e.g., redirect to paypalPayment.html)
        return render_template('payPal.html')

    # Handle other payment methods or show an error page
    return "Invalid payment method selected."
if __name__ == '__main__':
    app.run(debug=True)
